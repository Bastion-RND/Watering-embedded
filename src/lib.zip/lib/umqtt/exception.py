class MQTTException(Exception):
    pass
